$(document).ready(function () {	
	let provider;
	let signer
	async function initConnect() {
		provider = new ethers.providers.Web3Provider(window.ethereum)	

	}


	$("#connect").click(async function async() {
		initConnect();
		await provider.send("eth_requestAccounts", []);
		signer = provider.getSigner()
		console.log(signer);
		$("#connect").text(await signer.getAddress());
		

	});


	$("#get_balance").click(async function async() {
		await provider.send("eth_requestAccounts", []);
		signer = provider.getSigner()
		console.log(await provider.getResolver("ricmoo.eth"));
		$("#balance").text(await provider.getResolver("ricmoo.eth"));
		//can also return a specific ENS name balance
		//await provider.getBalance("ricmoo.eth");


	$("#add_candidate").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];
		let name = $('#candidate_name').val();
		await contract.methods
			.addCandidate(name)
			.send({ from: account }, function (err, res) {
				if (err) {
					console.log("An error occured", err)
					return
				}
				console.log("Hash of the transaction: " + res)

			});
	});

	$("#add_voter").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];
		let name = $('#voter_wallet').val();
		await contract.methods
			.addVoter(name)
			.send({ from: account }, function (err, res) {
				if (err) {
					console.log("An error occured", err)
					return
				}
				console.log("Hash of the transaction: " + res)

			});
	});

	$("#get_list").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];

		let count = await contract.methods
			.getCandidateCount()
			.call({ from: account });
		var candidates = "";
		$("#candidate_buttons").empty();
		for (var i = 0; i < count; i++) {

			let canidateNm = await contract.methods
				.candidates(i)
				.call({ from: account });
			candidates = canidateNm + ", " + candidates;
			var r = $('<button value="' + canidateNm + '">' + canidateNm + '</button>');
			r.click(function () { vote(this); });
			console.log(r);
			$("#candidate_buttons").append(r);
		}
		$("#candidates").text("click on button below to vote");
	});

	$("#start").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];

		await contract.methods
			.startElection()
			.send({ from: account }, function (err, res) {
				if (err) {
					console.log("An error occured", err)

					return
				}
				console.log("Hash of the transaction: " + res)
			});
	});

	$("#vote").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];
		console.log("name " + $(this).val());
		let name = $('#candidate_name_to_vote').val();    
		console.log(name)
		await contract.methods
		  .vote(name)
		  .send({ from: account}, function (err, res) {
			if (err) {
			  console.log("An error occured", err)
			  $("#error").text(JSON.stringify(err.message));
			  return
			}
			console.log("Hash of the transaction: " + res)
		  });
	});
	$("#get_leader").click(async function async() {
		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];
		let status = await contract.methods
			.currentLeadingCandidate()
			.call({ from: account });
		$("#leader").text(JSON.stringify(status));

	});
	$("#end").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];

		await contract.methods
			.endElection()
			.send({ from: account }, function (err, res) {
				if (err) {
					console.log("An error occured", err)
					return
				}
				console.log("Hash of the transaction: " + res)
			});
	});

	$("#get_winner").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];
		let winner = await contract.methods
			.getWinner()
			.call({ from: account });
		let maxVote = await contract.methods
			.maxVoteCount()
			.call({ from: account });
		$("#winner").text(JSON.stringify(winner) + " ( votes "+ maxVote + " )");
	});

	$("#restart").click(async function async() {

		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];

		await contract.methods
			.restartElection()
			.send({ from: account }, function (err, res) {
				if (err) {
					console.log("An error occured", err)
					return
				}
				console.log("Hash of the transaction: " + res)
			});
	});
	async function vote(e) {
		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];

		console.log($(e).val());

		await contract.methods
			.vote($(e).val())
			.send({ from: account }, function (err, res) {
				if (err) {
					console.log("An error occured", err)
					$("#error").text(JSON.stringify(err.message));
					return
				}
				console.log("Hash of the transaction: " + res)
			});
	}


});
});
